<template>
  <v-container fluid>
    <v-flex align="center">
        <input type="checkbox"
          :true-value="1"
          :false-value="0"
          v-model="image"
          id="checkbox1"
        >
        <label for="checkbox1">{{data.image}}</label>
        <br>
        <v-text-field
          outlined
          :disabled="data.$image = '0'"
          label="image_path"
          type="text"
          v-model="image_path"
          @input="setOptionText(optionText)"
        ></v-text-field>
        <v-text-field
          outlined
          :disabled="!image"
          label="image_outputpath"
          type="text"
          v-model="image_outputpath"
          @input="setOptionText(optionText)"
        ></v-text-field>
      </v-flex>
        <br>
        <v-flex align="center">
        <input type="checkbox"
          :true-value="1"
          :false-value="0"
          v-model="video"
          @change="setCorrect(isCorrect2)"
          id="checkbox2"
        >
        <label for="checkbox2">Video:</label>
        <br>
        <v-text-field
          outlined
          :disabled="!isCorrect2"
          label="video_path"
          type="text"
          v-model="video_path"
          @input="setOptionText(optionText)"
        ></v-text-field>
        <v-text-field
          outlined
          :disabled="!isCorrect2"
          label="video_outputpath"
          type="text"
          v-model="video_outputpath"
          @input="setOptionText(optionText)"
        ></v-text-field>
      </v-flex>
      <v-flex align="center">
        <input type="checkbox"
          :true-value="1"
          :false-value="0"
          v-model="camera"
          @change="setCorrect(isCorrect3)"
          id="checkbox3"
        >
        <label for="checkbox3">Realtime:</label>
        <v-text-field
          outlined
          :disabled="!isCorrect3"
          label="camera_path"
          type="text"
          v-model="camera_path"
          @input="setOptionText(optionText)"
        ></v-text-field>
      </v-flex>
      <v-btn
            dark
            class="mt-4 btn-pers"
            @click="enter">
            Download
      </v-btn>
    </v-container>
</template>

<script>
import DownloadService from '@/services/DownloadService'
export default {
  data () {
    return {
      data: {
      image: false,
      video: false,
      camera: false,
      image_path:'0',
      image_outputpath: '0',
      video_path: '0',
      video_outputpath: '0',
      camera_path: '0' 
      }
    }
  },
  async send () {
    try {
      await DownloadService.index(this.data)
      this.$
    } catch (err) {
      console.log(err)
    }
  },
  methods: {
    setCorrect (e) {
      this.$emit('set-correct', 
        e
      )
    },
    setOptionText (text) {
      this.$emit('set-option-text', {
        optionText: text
      })
    }
  }
}
</script>

<style scoped>
</style>
