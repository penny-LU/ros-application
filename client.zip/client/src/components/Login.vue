<template>
    <v-layout justify-center>
      <v-flex justify-center absolute>
      <v-card class="white rounded-lg" elevation="12">
        <v-toolbar :elevation="1" dense dark justify-center>
          <v-toolbar-title class="mytitle pt-1 pl-1">Login</v-toolbar-title>
        </v-toolbar>
        <v-card-text class="d-flex justify-center" flat>
         <div class="pl-6 pr-6 pt-2 pb-2">
          <form
            @submit.prevent="login" v-on:keyup.enter="login">
          <v-text-field
            label="Email*"
            v-model="email"></v-text-field>
          <br>
          <v-text-field
            label="Password*"
            type="password"
            :rules="rules"
            counter="32"
            v-model="password"
            ></v-text-field>
            <br>
          <div class="textsize alternative-option mt-4">
          You don't have an account? <span class="change pl-2" @click="navigateTo({name: 'register'})">Register</span>
          </div>
          <v-btn
            dark
            class="mt-4 btn-pers"
            @click="login">
            Login
          </v-btn>
          <br>
          <p class="forgot-password text-center mt-2 mb-4">
            <router-link to="/forgot-password">forget password?</router-link>
          </p>
          <br>
          <div class="error" v-html="error" />
          </form>
        </div>
      </v-card-text>
    </v-card>
    </v-flex>
  </v-layout>
</template>

<script>
import AuthenticationService from '../services/AuthenticationService'
export default {
  data () {
    return {
      email: '',
      password: '',
      error: null,
      rules: [v => v.length <= 32 || 'Max 32 characters']
    }
  },
  methods: {
    async login () {
      try {
        const response = await AuthenticationService.login({
          email: this.email,
          password: this.password
        })
        this.$store.dispatch('setToken', response.data.token)
        this.$store.dispatch('setUser', response.data.user)
        this.$router.push({
          name: 'download'
        })
      } catch (error) {
        this.error = error.response.data.error
      }
    },
    navigateTo (route) {
      this.$router.push(route)
    }
  }
}
</script>

<style scoped>
.error{
  color:red;
}
.change {
  cursor: pointer;
}
.change:hover {
  border-bottom:1px #000 solid; padding-bottom:5px;
  color:rgb(106, 223, 255);
}
.mytitle {
  font-size: 150%;
}
.forgot-password {
  font-size: 10px
}
.textsize{
  font-size: 18px
}

</style>
